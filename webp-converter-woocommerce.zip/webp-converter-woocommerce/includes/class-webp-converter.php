<?php
class WebP_Converter {
  public function __construct() {
    // инициализация плагина
    add_filter( 'wp_handle_upload', array( $this, 'convert_to_webp' ) );
  }
  
  // функция для конвертации изображений в формат WebP
  public function convert_to_webp( $args ) {
    // проверяем, поддерживает ли сервер формат WebP
    if ( !imagewebp( imagecreatetruecolor( 1, 1 ) ) ) {
      return $args;
    }
    
    // получаем информацию об изображении
    $uploaded_file = $args['file'];
    $file_info = wp_check_filetype( $uploaded_file );
    
    // проверяем, является ли файл изображением
    if ( strpos( $file_info['type'], 'image' ) === false ) {
      return $args;
    }
    
    // получаем путь к файлу
    $file_path = $args['file'];
    
    // конвертируем изображение в формат WebP
    $image = wp_get_image_editor( $file_path );
    if ( !is_wp_error( $image ) && $image->mime_type != 'image/webp' ) {
      $image->set_quality( 80 );
      $image->set_mime_type( 'image/webp' );
      $image->save( $file_path . '.webp' );
      
      // удаляем исходный файл изображения
      unlink( $file_path );
      
      // переименовываем файл WebP
      rename( $file_path . '.webp', $file_path );
      
      // обновляем данные о размерах изображения
      $metadata = wp_generate_attachment_metadata( $args['attachment_id'], $file_path );
      wp_update_attachment_metadata( $args['attachment_id'], $metadata );
    }
    return $args;
  }
  
  public function convert_images() {
    // конвертируем все существующие изображения на сайте
    $args = array(
      'post_type'      => 'attachment',
      'post_mime_type' => 'image',
      'posts_per_page' => -1,
      'post_status'    => 'any'
    );
    $attachments = get_posts( $args );
    foreach ( $attachments as $attachment ) {
      // конвертируем изображение, используя функцию convert_to_webp
      $this->convert_to_webp( array( 'attachment_id' => $attachment->ID, 'file' => get_attached_file( $attachment->ID ) ) );
    }
  }
}

function webp_converter_init() {
  // проверяем, включена ли опция конвертации изображений в формат WebP
  $convert_to_webp = get_option( 'webp_converter_enabled', false );
  if ( $convert_to_webp ) {
    // создаем экземпляр класса и запускаем конвертацию изображений
    $webp_converter = new WebP_Converter();
    $webp_converter->convert_images();
  }
}
add_action( 'init', 'webp_converter_init' );
