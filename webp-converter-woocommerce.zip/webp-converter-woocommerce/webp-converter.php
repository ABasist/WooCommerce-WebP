<?php
/*
Plugin Name: WebP Converter for WooCommerce
Plugin URI: https://abasist.pp.ua
Description: Convert product images to WebP format for better performance
Version: 1.0.0
Author: Anatoliy Basist
Author URI: https://abasist.pp.ua
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
*/

// запускаем плагин
require_once( plugin_dir_path( __FILE__ ) . 'class-webp-converter.php' );
$webp_converter = new WebP_Converter();

function webp_converter_init() {
    // проверяем, включена ли опция конвертации изображений в формат WebP
    $convert_to_webp = get_option( 'webp_converter_enabled', false );
    if ( $convert_to_webp ) {
        // создаем экземпляр класса и запускаем конвертацию изображений
        $webp_converter = new WebP_Converter();
        $webp_converter->convert_images();
    }
}
add_action( 'init', 'webp_converter_init' );
